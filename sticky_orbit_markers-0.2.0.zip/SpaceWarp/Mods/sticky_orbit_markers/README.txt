# Sticky Orbit Markers
This mod aims to allow you to see your pinned (right-clicked) periapsis and apoapsis markers while using the maneuver tool.

## Compatibility
Tested with Kerbal Space Program 2 v0.1.0.0.20892

## Install
1. Download and install [SpaceWarp](https://spacedock.info/mod/3257/Space%20Warp)
2. Download and extract this mod into your KSP 2 install folder (usually "Kerbal Space Program 2")
3. Start the game, fly a rocket, open Map View and enjoy your sticky markers!